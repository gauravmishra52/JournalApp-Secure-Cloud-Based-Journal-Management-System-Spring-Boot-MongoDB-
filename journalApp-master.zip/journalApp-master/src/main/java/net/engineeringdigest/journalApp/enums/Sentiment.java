package net.engineeringdigest.journalApp.enums;

public enum Sentiment {
    HAPPY,
    SAD,
    ANGRY,
    ANXIOUS;
}
